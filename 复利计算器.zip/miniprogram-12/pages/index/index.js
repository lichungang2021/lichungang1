// pages/kj/ForAndSum/index.js
var start, end, sum,s; 
Page({
  startNum: function(e) {
    start = parseInt(e.detail.value);
  },
  endNum: function(e) {
    end = parseFloat(e.detail.value); 
  },
  calc: function() {
    s = start;
    for (var i = 1; i <= 5; ++i) {
      sum = s + s * end; //利用for循环求和
      s=sum;
    }
    this.setData({
      sum: s //将全局变量sum的值渲染到视图层
    })
  }
})